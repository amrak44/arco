﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string V = "200000020";
        private const string W = "AST%3AComputerSystem";
        public MainWindow()
        {

            InitializeComponent();

            lbl_Total.Content = tb_targets.LineCount;

            ArrayList rrn = new ArrayList();

            List<ComboBoxPairs> typeList = new List<ComboBoxPairs>();
            typeList.Add(new ComboBoxPairs("Asset", "AST%3AComputerSystem"));
            typeList.Add(new ComboBoxPairs("Incident", "HPD%3AHelp+Desk"));
            typeList.Add(new ComboBoxPairs("Work Order", "WOI%3AWorkOrder"));
            typeList.Add(new ComboBoxPairs("Changes", "CHG%3AInfrastructure+Change"));
            typeList.Add(new ComboBoxPairs("Tasks", "TMS%3ATask&"));
            cmb_type.DisplayMemberPath = "critName";
            cmb_type.SelectedValuePath = "critValue";
            cmb_type.ItemsSource = typeList;
            cmb_type.SelectedIndex = 0;





        }






        private void btn_query_Click(object sender, RoutedEventArgs e)
        {

            string criteria = V; // ci name*
            string form = W;
            int batchsize = 40;
            List<string> entries = new List<string>(
                tb_targets.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None));

            int i = entries.Count;
            rtbSelection(tb_targets.Text);
            string Criteria = cmb_crit.SelectedValue.ToString();

            string Target = "https://mn-itservices.us.onbmc.com/arsys/forms/onbmc-s/SHR%3ALandingConsole/Default+Administrator+View/?mode=search&F304255500=" + cmb_type.SelectedValue.ToString() + "&F1000000076=FormOpenNoAppList&F303647600=SearchTicketWithQual&F304255610=" + Criteria + "\'=\"";
            List<string> unclean_targets = new List<string>(
             tb_targets.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None));
            int Counter = 0;
            int TotalCount = unclean_targets.Count;
            int batchSize = 41;
            var FinalString = "";

            bool Ready = false;


            foreach (string entry in unclean_targets)

            {
                Ready = false;
                TotalCount--;

                if (Counter == batchSize)
                {

                    FinalString += entry + "\"OR'" + Criteria + "'=\"";
                    Ready = true;
                    Counter = 0;

                }
                Counter++;


                if (TotalCount == 0)
                {
                    Ready = true;
                    FinalString += "'" + entry + "\"";
                }

                if (Ready)
                {
                    string browser = Target + FinalString;
                    try
                    {
                        System.Diagnostics.Process.Start(new ProcessStartInfo
                        {

                            FileName = browser,

                            UseShellExecute = true
                        });


                    }
                    catch (System.ComponentModel.Win32Exception noBrowser)
                    {
                        if (noBrowser.ErrorCode == -2147467259)
                            MessageBox.Show(noBrowser.Message);
                    }
                    catch (System.Exception other)
                    {
                        MessageBox.Show(other.Message);
                    }

                    FinalString = null;
                    FinalString = Target;
                    Counter = 0;

                }
                if (!Ready)
                {
                    FinalString += entry + "\"OR'" + Criteria + "'=\"";
                }
            }


            //  System.Diagnostics.Process.Start(Target + FinalString);

        }

        private Array rtbSelection(String e)
        {
            string splitlines = e;
            List<string> strings  = new List<string>(
    splitlines.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries));
            
            return strings.ToArray();


        }


        private void cmb_type_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int targetItem = cmb_type.SelectedIndex;

            if (targetItem.Equals(0))
            {
                List<ComboBoxPairs> critListAsset = new List<ComboBoxPairs>();
                critListAsset.Add(new ComboBoxPairs("CI Name*", "200000020"));
                critListAsset.Add(new ComboBoxPairs("Serial_Number", "200000001"));
                critListAsset.Add(new ComboBoxPairs("ReconciliationIdentity", "400129200"));
                critListAsset.Add(new ComboBoxPairs("Tag_Number", "260100004"));
                critListAsset.Add(new ComboBoxPairs("Accounting_Code", "260100001"));
                critListAsset.Add(new ComboBoxPairs("Building", "260000001"));
                critListAsset.Add(new ComboBoxPairs("Category", "200000003"));
                critListAsset.Add(new ComboBoxPairs("Part Number", "200000013"));
                critListAsset.Add(new ComboBoxPairs("Company", "1000000001"));
                critListAsset.Add(new ComboBoxPairs("Cost_Center", "260100007"));
                critListAsset.Add(new ComboBoxPairs("CreatedByLoginName", "270000670"));
                critListAsset.Add(new ComboBoxPairs("Domain", "260140117"));
                critListAsset.Add(new ComboBoxPairs("Floor", "260000004"));
                critListAsset.Add(new ComboBoxPairs("Instance_Id", "179"));
                critListAsset.Add(new ComboBoxPairs("Inventory_Name", "304386891"));
                critListAsset.Add(new ComboBoxPairs("Invoice_Number", "260100009"));
                critListAsset.Add(new ComboBoxPairs("Manufacturer", "240001003"));
                critListAsset.Add(new ComboBoxPairs("Manufacturer_Name", "240001003"));
                critListAsset.Add(new ComboBoxPairs("Manufacturer_OS", "270000570"));
                critListAsset.Add(new ComboBoxPairs("Model_Number", "240001002"));
                critListAsset.Add(new ComboBoxPairs("Owner_contact", "301002800"));
                critListAsset.Add(new ComboBoxPairs("Owner_name", "301002900"));
                critListAsset.Add(new ComboBoxPairs("Requisition_ID", "263000017"));
                critListAsset.Add(new ComboBoxPairs("Room", "260000005"));
                critListAsset.Add(new ComboBoxPairs("SupplierName", "240001008"));
                critListAsset.Add(new ComboBoxPairs("System_Role", "260000002"));
                critListAsset.Add(new ComboBoxPairs("SystemType", "301016700"));
                critListAsset.Add(new ComboBoxPairs("Type", "200000004"));
                cmb_crit.DisplayMemberPath = "critName";
                cmb_crit.SelectedValuePath = "critValue";
                cmb_crit.ItemsSource = critListAsset;
                cmb_crit.SelectedIndex = 0;
            }

            if (targetItem.Equals(2))
            {

                List<ComboBoxPairs> critListWorkOrder = new List<ComboBoxPairs>();
                critListWorkOrder.Add(new ComboBoxPairs("Work Order ID", "1000000182"));
                critListWorkOrder.Add(new ComboBoxPairs("Request Assignee", "1000003230"));
                critListWorkOrder.Add(new ComboBoxPairs("Summary", "1000000000"));
                critListWorkOrder.Add(new ComboBoxPairs("Customer Company", "1000003299"));
                critListWorkOrder.Add(new ComboBoxPairs("Submitter", "2"));
                cmb_crit.DisplayMemberPath = "critName";
                cmb_crit.SelectedValuePath = "critValue";
                cmb_crit.ItemsSource = critListWorkOrder;
                cmb_crit.SelectedIndex = 0;
            }
            if (targetItem.Equals(1))
            {

                List<ComboBoxPairs> critListIncident = new List<ComboBoxPairs>();
                critListIncident.Add(new ComboBoxPairs("Incident Number", "1000000161"));
                critListIncident.Add(new ComboBoxPairs("Request Assignee", "1000003230"));
                critListIncident.Add(new ComboBoxPairs("Summary", "1000000000"));
                critListIncident.Add(new ComboBoxPairs("Customer Company", "1000003299"));
                critListIncident.Add(new ComboBoxPairs("Submitter", "2"));
                critListIncident.Add(new ComboBoxPairs("Request Assignee", "1000000422"));
                critListIncident.Add(new ComboBoxPairs("Summary", "1000000217"));
                critListIncident.Add(new ComboBoxPairs("Customer Company", "1000000218"));
                cmb_crit.DisplayMemberPath = "critName";
                cmb_crit.SelectedValuePath = "critValue";

                cmb_crit.ItemsSource = critListIncident;
                cmb_crit.SelectedIndex = 0;
            }
            if (targetItem.Equals(4))
            {

                List<ComboBoxPairs> critListTask = new List<ComboBoxPairs>();
                critListTask.Add(new ComboBoxPairs("TaskID", "10000006"));
                cmb_crit.DisplayMemberPath = "critName";
                cmb_crit.SelectedValuePath = "critValue";
                cmb_crit.ItemsSource = critListTask;
                cmb_crit.SelectedIndex = 0;
            }
            if (targetItem.Equals(3))
            {

                List<ComboBoxPairs> critListChange = new List<ComboBoxPairs>();
                critListChange.Add(new ComboBoxPairs("ChangeID", "1000000182"));
                critListChange.Add(new ComboBoxPairs("Request_Assignee", "1000003230"));
                critListChange.Add(new ComboBoxPairs("Customer_Company", "1000003299"));
                cmb_crit.DisplayMemberPath = "critName";
                cmb_crit.SelectedValuePath = "critValue";
                cmb_crit.ItemsSource = critListChange;
                cmb_crit.SelectedIndex = 0;
            }
        }

        private void btn_clipboard_Click(object sender, RoutedEventArgs e)
        {
            string Criteria = cmb_crit.SelectedValue.ToString();
            int Counter = 2;
              List<string> Counting = new List<string>(
    tb_targets.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None));
            int TotalCount = Counting.Count();

            var FinalString = "";

            bool Ready = false;
            var newText = "";
            newText = null;



            foreach (string entry in Counting)
            {
                if (Counter == TotalCount)
                {

                    newText += "'" + Criteria + "'' LIKE \"" + entry + "\"";
                    Clipboard.SetText(newText);

                }
                else
                {
                    newText += "'" + Criteria + "' LIKE \"" + entry + "\" OR ";


                }

                Counter++;


            }
        }

        private void tb_targets_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (lbl_Total != null)
            {
                lbl_Total.Content = tb_targets.LineCount;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void tb_targets_MouseDown(object sender, MouseButtonEventArgs e)
        {
            tb_targets.SelectAll();

        }


    }
}

public class ComboBoxPairs
{
    public string critName { get; set; }
    public string critValue { get; set; }
    public ComboBoxPairs(string CritName, string CritValue)
    {
        critName = CritName;
        critValue = CritValue;

    }

}